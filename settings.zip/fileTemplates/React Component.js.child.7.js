import React, { Component } from 'react'
import { connect } from 'react-redux'

function mapStateToProps (state) {
  return {}
}

function mapDispatchToProps (dispatch) {
  return {}
}

class ${NAME} extends Component {
  render () {
    return (
      <div>
        
      </div>
    )
  }
}

export default connect(
  mapStateToProps,
)(${NAME})