import React from 'react'
import PropTypes from 'prop-types'

${NAME}.propTypes = {
  
}

function ${NAME} (${props}) {
  return (
    <div>
    
    </div>
  )
}

export default ${NAME}