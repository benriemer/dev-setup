import React, { Component } from 'react'
import PropTypes from 'prop-types'

class ${NAME} extends Component {
  render () {
    return (
      <div>
        
      </div>
    )
  }
}

${NAME}.propTypes = {}

export default ${NAME}