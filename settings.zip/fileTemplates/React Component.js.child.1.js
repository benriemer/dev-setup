import React, { Component } from 'react'

class ${NAME} extends Component {
  render () {
    return (
      <div>
        
      </div>
    )
  }
}

export default ${NAME}