import React from 'react'

class ${NAME} extends React.Component {
    return (
      <div>
        
      </div>
    )
}

export default ${NAME}