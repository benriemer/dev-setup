import React from 'react'

function ${NAME} (props) {
  return (
    <div>
    
    </div>
  )
}

export default ${NAME}