import React from 'react'

class $!NAME extends React.Component {
    constructor (${PROP_TYPES}) {
        super(${PROP_TYPES})
        }
        
  render() {
    return $COMPONENT_BODY
  }
}

export default $!NAME