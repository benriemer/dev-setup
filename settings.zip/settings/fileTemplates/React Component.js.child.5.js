import React, { Component } from 'react'

class ${NAME} extends Component {
    constructor (${props}) {
        super(${props})

            this.state = {}

  }

  render () {
    return (
      <div>
        
      </div>
    )
  }
}

export default ${NAME}