import React from 'react'

function ${NAME}() {
  return (
    <div>

    </div>
  )
}

export default ${NAME}