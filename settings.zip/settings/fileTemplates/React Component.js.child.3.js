import React from 'react'

const ${NAME} = (${props}) => (
  
)

export default ${NAME}